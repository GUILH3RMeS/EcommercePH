<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'elementor-packages-ui','deps'=>['react','react-dom',],];