<?php
if(!defined('ABSPATH')){exit;}return['handle'=>'elementor-packages-locations','deps'=>['react',],];